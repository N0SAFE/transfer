<?php
$content = json_decode(trim(file_get_contents("php://input")));

function base64_to_file( $base64_string, $output_file_path ) {
    $ifp = fopen( $output_file, "mb" );
    fwrite( $ifp, $base64_decode( $base64_string ) );
    fclose( $ifp);
    return($output_file);
}
echo base64_to_file($content["string"], $content["path"]);