<?php
session_start();
if(!isset($_SESSION["path"]))
{
    $temp=explode("\\", getcwd());
    array_splice($temp , count($temp)-2);
    $temp = implode("/", $temp);
    $_SESSION["path"]=$temp;
}
echo $_SESSION["path"];