<?php
session_start();
$content = trim(file_get_contents("php://input"));

$tempPath = $_SESSION["path"];

if (substr($content, 1, 2)== substr($_SESSION["path"], 1, 2)){
    if(file_exists($content)){
        $_SESSION["path"]= $content;
    }
}
else{
    $count = substr_count($content , "../");

    $tempPath=explode("/", $tempPath);
    $tempPath[count($tempPath)-1] == ""?array_splice($tempPath , count($tempPath)-1):"";                          
    array_splice($tempPath , count($tempPath)-$count);
    $tempPath = implode("/", $tempPath);
    $content = str_replace("../" , "" , $content);
    if(substr($tempPath , -1)!= "/"){
        $tempPath.="/";
    }
    $tempPath.=$content;
    if(file_exists($tempPath))
    {
        $_SESSION["path"]=substr($tempPath, strlen($tempPath)-1) == "/" ? substr($tempPath, 0, strlen($tempPath)-1):$tempPath;
        $_SESSION["path"] = substr($_SESSION["path"], -2) == "/." ? substr($_SESSION["path"], 0, strlen($_SESSION["path"])-2):$_SESSION["path"];
        $_SESSION["path"] = substr($_SESSION["path"], -3) == "/.." ? substr($_SESSION["path"], 0, strlen($_SESSION["path"]) - 3) : $_SESSION["path"];
        echo $_SESSION["path"];
    }else{
        echo "error";
    }
}