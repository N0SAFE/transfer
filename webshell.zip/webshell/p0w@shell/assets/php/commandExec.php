<?php
//* fichier pour permettre l'exec au sein du serv  avec shell_exec et sur le path $_SESSION[path]
$content = trim(file_get_contents("php://input"));
session_start();
if(!isset($_SESSION["path"]))
{
    $temp=explode("\\", getcwd());
    array_splice($temp , count($temp)-2);
    $temp = implode("/", $temp);
    $_SESSION["path"]=$temp;
}
if($content == "dir"){
    if(is_dir($_SESSION["path"])){
        echo json_encode(scandir($_SESSION["path"]));
    }else{
        echo json_encode([basename($_SESSION["path"])." is not a directory"]);
    }
    
}
