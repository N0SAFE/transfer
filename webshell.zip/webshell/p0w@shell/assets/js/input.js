import { exec } from './cmdExe.js'
import { getHistory } from './history.js'
import { getFromFile } from "./function.js"
export async function onShellCmdKeyDown(event) {
    const history = getHistory()
    switch (event.key) {
        case "Enter":
            if (this.value) {
                history.addToHistory(this.value)
            }
            history.resetPositionHistory()

            let label = document.createElement("label")
            label.innerHTML = await getFromFile("./php/CurrenPath.php") + ">"
            label.classList.add("shell-prompt")

            let span = document.createElement("span")
            span.appendChild(label)
            span.style.display = "block"
            span.innerHTML += " " + this.value
            document.getElementById("shell-content").appendChild(span)

            let array = await exec(this.value.split("%!%"))
            array = array == undefined ? [] : array
            let dir = document.createElement("div")
            dir.style.display = "flex"
            dir.style.flexDirection = "column"
            dir.style.minHeight = "15px"

            array.forEach(item => {
                let spanCopy = document.createElement("span")
                spanCopy.innerHTML = item
                dir.appendChild(spanCopy)
            })

            document.getElementById("shell-content").appendChild(dir)

            this.value = ""
            break
        case "ArrowUp":
            history.upHistory()
            this.value = history.getCmdHistory() != undefined ? history.getCmdHistory() : ""
            setTimeout(() => { document.getElementById("shell-cmd").setSelectionRange(document.getElementById("shell-cmd").value.length, document.getElementById("shell-cmd").value.length) }, 2)

            break
        case "ArrowDown":
            history.downHistory()
            this.value = history.getCmdHistory() != undefined ? history.getCmdHistory() : ""
            break
    }
}