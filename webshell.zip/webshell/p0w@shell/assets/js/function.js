import * as TimerClasse from "./tool/Timer.js"

// util
export class Timer {
    // ! all can be:    stop with stop()
    // !                pause with pause()
    // !                start/restart with start()
    // !                return state with getStateRunning()
    // !                return time left with getTimeLeft()

    // ! func with exec after can set the func to exec after with setFunction(Function, ...args)

    // ! set timer with function in end
    static timeout(Function, delay, ...funcArgs) {
        return new TimerClasse.TimerTimeout(Function, delay, ...funcArgs)
    }

    // ! run an infinit loop and run first loop after timinig
    static infinityLooper(Function, delay, ...funcArgs) {
        return new TimerClasse.TimerInfinityReapeter(Function, delay, ...funcArgs)
    }

    // ! run an infinit loop and run instant 
    static infinityLooperInstant(Function, delay, ...funcArgs) {
        return new TimerClasse.TimerInfinityReapeterInstant(Function, delay, ...funcArgs)
    }

    // ! run a loop with number of loop in argument and run first loop after timing
    static looper(Function, delay, numberOfLoop, ...funcArgs) {
        return new TimerClasse.TimerReapeter(Function, delay, numberOfLoop, ...funcArgs)
    }

    // ! run a loop with number of loop in argument and run execution instant
    static looperInstant(Function, delay, numberOfLoop, ...funcArgs) {
        return new TimerClasse.TimerReapeterInstant(Function, delay, numberOfLoop, ...funcArgs)
    }

    // ! run a loop with number of loop in argument, run first loop after timing and run a function after the loop as finish
    static looperRunAfter(Function, delay, numberOfLoop, ...funcArgs) {
        return new TimerClasse.TimerReapeaterWithFunctionAfter(Function, delay, numberOfLoop, ...funcArgs)
    }

    // ! run a loop with number of loop in argument, run execution instant and run a function after the loop as finish
    static looperInstantRunAfter(Function, delay, numberOfLoop, ...funcArgs) {
        return new TimerClasse.TimerReapeaterInstantWithFunctionAfter(Function, delay, numberOfLoop, ...funcArgs)
    }
}


export async function importScript(path) {
    const module = await
    import (path)
    return module
}

// info: server side to have post [$content = trim(file_get_contents("php://input"))]
// As with JSON, use the Fetch API & ES6
// base path = "project/creation/.assets/"
export async function getFromFile(path, param = {}) {
    param.method = "POST"
    if (!param.from) { param.from = null }
    if (!param.typeRet) { param.typeRet = !param.retType ? null : param.retType }
    if (!param.data) { param.data = "" }
    if (param.stringify) { param.data = JSON.stringify(param.data) }

    let ret = '';
    try {
        await fetch("./assets/" + path, { method: param.method, body: param.data })
            .then((response) => {
                if (response.ok) {
                    return response.text();
                } else {
                    throw new Error('Server response wasn\'t OK on : ' + path);
                }
            })
            .then((json) => {
                ret = json;
            }).catch(err => console.log(err));
        switch (param.typeRet) {
            case "json":
                ret = JSON.parse(ret);
                if (param.from == "php") {
                    ret = Object.values(ret)[0]
                }
            default:
                ret = ret;
        }
        return ret;
    } catch (err) {}
};

export async function getPathFromServer(path) {
    let div = document.createElement('div')
    div.innerHTML = await getFromFile("php/getPath.php", { method: "POST", data: path })
    return div.cloneNode(true)
}


function getRandomInt(max, min = null) {
    if (min == null) {
        return Math.floor(Math.random() * max);
    } else {
        return clamp(Math.floor(Math.random() * max), min, max)
    }

}

export function clamp(num, min, max) {
    return Math.min(Math.max(num, min), max);
}

export function setAttributeLoop(element, arrayKey, arrayValue) {
    if (arrayKey.length != arrayValue.length) {
        throw "the two array as not the same length"
    }
    for (var i = 0; i < arrayKey.length; i++) {
        element.setAttribute(arrayKey[i], arrayValue[i]);
    }
}

export function appendChildLoop(arrayParent, arrayChild) {
    if (arrayKey.length != arrayValue.length) {
        throw "the two array as not the same length"
    }
    for (var i = 0; i < arrayParent.length; i++) {
        arrayParent[i].appendChild(arrayChild[i])
    }
}

export function addClassLoop(arrayElement, arrayClass, elementIsSame = true) {
    if (!elementIsSame) {
        if (arrayElement.length != arrayClass.length) {
            throw "the two array as not the same length"
        }
        for (var i = 0; i < arrayElement.length; i++) {
            arrayElement[i].classList.add(arrayClass[i])
        }
    } else {
        for (var i = 0; i < arrayClass.length; i++) {
            arrayElement.classList.add(arrayClass[i])
        }
    }
}

export function removeClassLoop(arrayElement, arrayClass, elementIsSame = true) {
    if (!elementIsSame) {
        if (arrayElement.length != arrayClass.length) {
            throw "the two array as not the same length"
        }
        for (var i = 0; i < arrayElement.length; i++) {
            arrayElement[i].classList.remove(arrayClass[i])
        }
    } else {
        for (var i = 0; i < arrayClass.length; i++) {
            arrayElement.classList.remove(arrayClass[i])
        }
    }
}

export function addFocus(x, element) {
    x.classList.add('isFocus');
    if (x.type == "textarea") {
        element.classList.add('focusElement');
    } else {
        element.classList.add('focusElement');
    }
    console.log(element)
    console.log(x)
    LoopTestInputOnFocus(x, element);
}
export function removeFocus(x, element) {
    x.classList.remove('isFocus');
    if (x.type == "textarea") {
        try {
            element.removeChild(element.getElementsByTagName("span")[0])
        } catch {}
        element.classList.remove('focusElement');
    } else {
        try {
            element.removeChild(element.getElementsByTagName("span")[0])
        } catch {}
        element.classList.remove('focusElement');
    }
}
export function LoopTestInputOnFocus(x, element) {
    var name;
    var box;
    if (x.classList.contains('isFocus')) {
        if (x.type == "textarea") {
            box = element;
            name = box.dataset.nsTextArea;
            // console.log(name);
        } else {
            box = element;
            name = box.dataset.nsText;
            // console.log(name);
        }
        // console.log(x.value)
        if (x.value) {
            box.innerHTML = setCursorRealTimeInput(x);
        } else if (name) {
            box.innerHTML = name;
        } else {
            box.innerHTML = "Lorem Ipsum";
        }
        setTimeout(function() {
            LoopTestInputOnFocus(x, element);
        }, 100);
    }
}
export function setCursorRealTimeInput(x) {
    return x.value.slice(0, x.selectionStart) + "<span>|</span>" + x.value.slice(x.selectionStart, x.value.length)
}
export function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}
export function returnSelfForValueDict(dict, index, elementToCatch) {
    var temp = null
    Object.entries(dict).forEach(([key, value]) => {
        if (value[index] == elementToCatch) {
            temp = key;
            return 0;
        }
    });
    return temp;
}

export function returnElementFromDictArray(index1, index2, dict, elementToCatch) {
    return dict[returnSelfForValueDict(dict, index1, elementToCatch)][index2]
}

export function getDatasetValueFromArrayNode(array, dataset, valueToSearch, Default = undefined) {
    let ret = Default
    Array.from(array).every(element => {
        if (element.dataset[dataset] == valueToSearch) {
            ret = element
            return false
        }
        return true
    })
    return ret
}

export function searchAndSetData(dataset, elseValue) {
    if (dataset != undefined && dataset != "") {
        return dataset
    }
    return elseValue
}

export function isInArray(toTest, ...args) {
    for (var arg of args) {
        if (toTest === arg)
            return true
    }
    return false
}

export function createidBase(base, len) {
    var optionBase = [10, 2, 64, 16]
    var strBase;
    switch (base) {
        case (optionBase[0]):
            strBase = "0123456789"
            break
        case (optionBase[1]):
            strBase = "01"
            break
        case (optionBase[2]):
            strBase = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_!"
            break
        case (optionBase[3]):
            strBase = "0123456789abcdef"
            break
    }
    var ret = ""
    for (var i = 0; i < len; i++) {
        ret += strBase[getRandomInt(strBase.length)]
    }
    return ret
}

export function personalizeSwitch(condition, array) {
    array.forEach(element => {
        if (element["value"] === condition) {
            console.log("test")
            element["function"]()
        }
    })
}

export function setStyleOnElement(styles, element) {
    Object.assign(element.style, styles);
}