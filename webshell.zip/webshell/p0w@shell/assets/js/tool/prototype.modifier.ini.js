class ModifiedPrototype {
    constructor() {
        this.prototype = {}
    }

    classNewPrototype(object, propertyName, value, moduleNameForConflict = "") {

        moduleNameForConflict = moduleNameForConflict != "" ? "[" + moduleNameForConflict + "]" : ""

        this.createNewBibl(Object.prototype.toString.call(object()))
        object.prototype[propertyName] = value
        this.prototype[Object.prototype.toString.call(object()) + moduleNameForConflict] = {
            "class": object,
            "property": value
        }

    }
    getPersonnalizedProperty(object, propertyName = null) {
        return propertyName == null ? this.prototype[object] : this.prototype[object][propertyName]
    }
    getAllObjectsWithPersonnalizedProperty() { return this.prototype }
    createNewBibl(biblName) {
        if (!this.isBilbExist) {
            this.prototype[biblName] = {}
        }
        return biblName
    }
    isBilbExist(biblName) {
        return Object.keys(this.prototype).includes(biblName)
    }
}

let modifiedPrototype

export function getModifiedPrototype() {
    return modifiedPrototype
}
export function modifiedNewPrototype(object, propertyName, value, moduleNameForConflict = "") {
    modifiedPrototype.classNewPrototype(object, propertyName, value, moduleNameForConflict)
}

export default function setModifiedPrototypeClass() {

    modifiedPrototype = new ModifiedPrototype()
    modifiedNewPrototype(Array, "asyncForEach", async function(callback, wait = true) {
        for (let i = 0; i < this.length; i++) {
            if (wait == false) {
                if (Object.prototype.toString.call(this[i]) == "[object Array]")
                    callback(...this[i])
                else
                    callback(this[i])
            } else {
                if (Object.prototype.toString.call(this[i]) == "[object Array]")
                    await callback(...this[i])
                else
                    await callback(this[i])
            }
        }
    })

    //  | same as : Object.prototype.add = (object, key, value) => {object[key] = value;}
    // \ /
    modifiedNewPrototype(Object, "add", (object, key, value) => {
        object[key] = value;
    })

}