import { clamp } from "./function.js"
class History {
    constructor() {}
    history = []
    index = 0

    addToHistory(cmd) {
        this.history.push(cmd)
    }
    upHistory() {
        this.index = clamp(this.index + 1, 1, this.history.length)
    }
    downHistory() {
        this.index = clamp(this.index - 1, 1, this.history.length)
    }
    resetPositionHistory() {
        this.index = 0
    }
    getCmdHistory() {
        return this.history[this.history.length - clamp(this.index, 0, this.history.length)]
    }
}
let history;
export function setHistory() {
    history = new History()
}
export function getHistory() {
    return history;
}