import setModifiedPrototypeClass from "./tool/prototype.modifier.ini.js"
import { getFromFile } from "./function.js"
import { onShellCmdKeyDown } from "./input.js"
import { setHistory } from "./history.js"

setHistory()
setModifiedPrototypeClass()


let input = document.getElementById("shell-cmd")
input.focus()
input.onkeydown = onShellCmdKeyDown



let label = document.getElementById("shell-prompt")
label.innerHTML = await getFromFile("./php/CurrenPath.php") + ">"

document.getElementById("shell").onclick = () => { input.focus() }