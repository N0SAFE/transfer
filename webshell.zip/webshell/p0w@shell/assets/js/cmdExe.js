import { getFromFile } from "./function.js";
export async function exec(...execStrings) {
    let ret;
    let label = document.getElementById("shell-prompt")
    await execStrings.asyncForEach(async function(execString) {
        if (execString.substr(0, 2) == "cd") {
            let fileName = execString.substr(2, execString.length - 1).trim() == "" ? "'empty'" : execString.substr(2, execString.length - 1).trim()
            let path = await getFromFile("./php/setCurrenPath.php", { data: fileName })
            path == "error" ? ret = ["le fichier " + fileName + " n'existe pas a " + await getFromFile("./php/CurrenPath.php")] : label.innerHTML = path + ">";
        } else if (execString == "clear") {
            let logo = document.getElementById("shell-logo").outerHTML
            document.getElementById("shell-content").innerHTML = logo
        } else {
            ret = await getFromFile("./php/commandExec.php", { data: execString, retType: "json" })
        }
    })

    return ret;
}